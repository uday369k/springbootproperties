package com.cognine.demo.EmpDemoSet;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext container = new AnnotationConfigApplicationContext("com");
		JdbcTemplate jdbcTemplate = container.getBean(JdbcTemplate.class);
		List<EmpData> data =jdbcTemplate.query("select * from employee", new RowMapper<EmpData>() {

			public EmpData mapRow(ResultSet rs, int rowNum) throws SQLException {
				EmpData e = new EmpData();
				e.setId(rs.getInt("empid"));
				e.setName(rs.getString("empname"));
				e.setSalary(rs.getDouble("empsalary"));
				return e;
			}
		});
		for(EmpData e:data) {
			System.out.println(e);
		}
	}
}