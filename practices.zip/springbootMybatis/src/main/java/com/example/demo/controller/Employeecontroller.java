package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.mapper.EmployeeMapper;
import com.example.demo.model.Employee;

@RestController
@RequestMapping("/rest/employee")
public class Employeecontroller {

	@Autowired
	private EmployeeMapper employeeMapper;

	@GetMapping("/all")
	public List<Employee> getAll() {
		return employeeMapper.findAll();

//	@GetMapping("/update")
//	public List<Employee> update(){
//		Employee employee = new Employee();
//		employee.setId(1);
//		employee.setName("aaa");
//		employee.setSalary(96325.25);
//		employeeMapper.insert(employee);
//		return employeeMapper.findAll();

//	}

	}

}
