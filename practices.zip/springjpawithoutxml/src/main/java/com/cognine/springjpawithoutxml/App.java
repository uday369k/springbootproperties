package com.cognine.springjpawithoutxml;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext container = new AnnotationConfigApplicationContext("com");
		EmployeeDao employeeDao = container.getBean(EmployeeDao.class);		
		List<Employee> allEmployeeDetails = employeeDao.getAllEmployeeDetails();
		for (Employee employee2 : allEmployeeDetails) {
			System.out.println(employee2);
		}
	}
}
