package demo;

public class Display {
	void print(int a,String b){
		System.out.println("Employee Details are:");
		System.out.println(a+" "+b); 
	}

}
