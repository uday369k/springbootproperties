package demo;

import java.util.List;

public class ModifyList {

	public void modifyObject(List<EmpData> listOfEmpData) {
		for (EmpData empData : listOfEmpData) {
			empData.setName("venu");
		}
	}
}
