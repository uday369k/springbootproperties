package demo;
import java.util.*;
public class ArrayListDemo{
	public static void main(String ar[]) {
List<StuData> al=new ArrayList<StuData>();
StuData s1=new StuData(1,"aaaa",78.7);
StuData s2=new StuData(1,"aaaa",78.7);
StuData s3=new StuData(3,"aadas",87.7);
al.add(s1);
al.add(s2);
al.add(s3);
for(StuData st:al) {
System.out.println(st.rollno);
System.out.println(st.name);
System.out.println(st.marks);
}
}
}