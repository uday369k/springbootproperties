package demo;

import java.util.*;

public class EmpDispaly extends EmpStore {
	public void display(List<EmpData> listOfEmpData) {
		for (EmpData empData : listOfEmpData) {
			System.out.println(empData);
		}
	}
}
