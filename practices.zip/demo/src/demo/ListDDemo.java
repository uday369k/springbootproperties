package demo;

import java.util.List;

public class ListDDemo {
	public static void main(String[] args) {
		EmpStore empStore = new EmpStore();
		List<EmpData> empData = empStore.getEmpData();
//		ModifyList modifyList = new ModifyList();
//		modifyList.modifyObject(empData);
		EmpDispaly empDispaly = new EmpDispaly();
		empDispaly.display(empData);
		
//		EmpData empData = new EmpData(1, "venu", "Hyd");
//		System.out.println(empData.getName());
//		EmpData empData1=empData;
//		empData1.setName("gopal");
//				System.out.println(empData.getName());
//				System.out.println(empData1.getName());

		
	}
}
