package demo;

import java.util.*;

public class EmpStore {
	public List<EmpData> getEmpData(){
		List<EmpData> listOfEmpData = new ArrayList<>();
		listOfEmpData.add(new EmpData(1, "venu", "hyd"));
		listOfEmpData.add(new EmpData(2, "gopal", "hyd"));
		listOfEmpData.add(new EmpData(3, "alla", "hyd"));
	return listOfEmpData;
	}
		
}