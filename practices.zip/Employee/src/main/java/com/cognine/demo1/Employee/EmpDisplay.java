package com.cognine.demo1.Employee;

import java.util.List;

import org.springframework.context.annotation.Configuration;
@Configuration

public class EmpDisplay {

	public void dispaly(List<EmpData> al) {
		for (EmpData x : al) {
			System.out.println(x);
		}
	}

}
