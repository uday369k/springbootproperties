package com.cognine.demo.MultipleInsert;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;import org.springframework.beans.factory.parsing.EmptyReaderEventListener;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class InsertData {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public void insertData(List<EmpData> listOfEmpData) {
		for (EmpData empData : listOfEmpData) {
			jdbcTemplate.update("insert into employee(empid,empname,empmobileno) values(?,?,?)",empData.getId(),empData.getName(),empData.getMobile());
		}
	}
}
