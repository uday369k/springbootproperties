package com.cognine.demo.MultipleInsert;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class UpdateRecords {
	@Autowired
	JdbcTemplate jdbcTemplate;
	public void updateData(List<EmpData> list) {
		for(EmpData emp:list) {
		jdbcTemplate.update("update employee set(empmobile) where empid(?)",emp.getId());
}
}
}