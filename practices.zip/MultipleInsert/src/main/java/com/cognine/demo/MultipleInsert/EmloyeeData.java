package com.cognine.demo.MultipleInsert;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Configuration;

@Configuration
public class EmloyeeData {
//	public List<EmpData> getEmpData() {
//		List<EmpData> al = new ArrayList<EmpData>();
//		al.add(new EmpData(1, "aaaa", "963258741"));
//		al.add(new EmpData(2, "bbbb", "987456321"));
//		al.add(new EmpData(1, "cccc", "963214587"));
//		return al;
//	}
	public List<EmpData> getEmpData() {
		List<EmpData> al = new ArrayList<EmpData>();
		al.add(new EmpData(1, "aaaa", "999999999"));
//		al.add(new EmpData(2, "bbbb", "888888888"));
//		al.add(new EmpData(1, "cccc", "777777777"));
		return al;
	}
}
