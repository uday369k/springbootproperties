package com.cognine.SpringJpaUpdate;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext container = new AnnotationConfigApplicationContext("com");
		EmployeeDao employeeDao = container.getBean(EmployeeDao.class);
		employeeDao.empUpdate();
	}
}
