package com.cognine.SpringJpaDelete;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
@Configuration
@EnableTransactionManagement
public class EntityManagerFactoryImpl {
	@Bean
	public LocalEntityManagerFactoryBean getLocalEntityManager() {
	LocalEntityManagerFactoryBean localEntityManagerFactoryBean=new LocalEntityManagerFactoryBean();
	localEntityManagerFactoryBean.setPersistenceUnitName("jpadeletedemo");
	return localEntityManagerFactoryBean;
	}
	@Bean
	public JpaTransactionManager getJpaTransactionManager() {
		JpaTransactionManager jpaTransactionManager=new JpaTransactionManager();
		jpaTransactionManager.setEntityManagerFactory(getLocalEntityManager().getObject());
		return jpaTransactionManager;
		
	}
}
