package com.example.demo.EmployeeDaoImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.dao.EmployeeDao;
import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;
@Repository
public class EmployeeDaoUpdate implements EmployeeDao {
	@Autowired
	EmployeeRepository repository;

	@Override
	public int update(Employee employee) {
		Employee e = new Employee();
		e.setEmpId(1);
		e.setEmpName("cccc");
		e.setEmpSalary("23650.59");
		e.setEmpMobileNo(null);
		repository.save(e);
		return 0;
	}

}
