package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;
@RestController
public class EmployeeController {
	
	
	
	@Autowired
	EmployeeService Service;
	
	@GetMapping("/update")
	public int update(@RequestBody Employee employee) {
//		System.out.println(employee);
		return Service.update(employee);
	
	}

}
