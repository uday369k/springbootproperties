package com.cognine.springdemo.jdbcset;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;


/**
 * Hello world!
 *
 */
public class App {
	public static void main( String[] args )
    {
    	AnnotationConfigApplicationContext container=new  AnnotationConfigApplicationContext("com");
    	JdbcTemplate jdbcTemplate=container.getBean(JdbcTemplate.class);
    	Set<Employee> listOfEmployee = jdbcTemplate.query("select * from employee",new ResultSetExtractor<Set<Employee>>() 
    	{
					public Set<Employee> extractData(ResultSet rs) throws SQLException, DataAccessException {
						Set<Employee> listOfEmployee = new HashSet<Employee>();
						while (rs.next()) {
							Employee employee = new Employee();
							employee.setId(rs.getInt("empid"));
							employee.setName(rs.getString("empname"));
							employee.setMobile(rs.getString("empmobile"));
							listOfEmployee.add(employee);
						}
						return listOfEmployee;
					}

				});

		for (Employee employee : listOfEmployee) {
			System.out.println(employee);
		}
    }
}
