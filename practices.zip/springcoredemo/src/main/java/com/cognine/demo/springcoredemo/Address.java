package com.cognine.demo.springcoredemo;

import org.springframework.context.annotation.Configuration;

@Configuration
public class Address {
	private String village="tadikonda";
	private String state="A.P";

	public String getVillage() {
		return village;
	}

	public void setVillage(String village) {
		this.village = village;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

}
