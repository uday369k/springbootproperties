package com.cognine.springjpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class EmployeeDao {

	@PersistenceContext
	EntityManager emManager;

	@Transactional
//	public void insertEmployee(Employee employee) {
//		emManager.persist(employee);
//	}

	public List<Employee> getAllEmployeeDetails() {
		return emManager.createQuery("select e from Employee e", Employee.class).getResultList();
	}
}
