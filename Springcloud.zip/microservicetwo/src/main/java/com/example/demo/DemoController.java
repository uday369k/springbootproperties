package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {

	@GetMapping("/getmobileno")
	public String getMobileNo() {
		return "9640067163";
	}
}
